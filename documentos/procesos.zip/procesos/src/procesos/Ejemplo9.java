package procesos;

import java.io.IOException;

public class Ejemplo9 {
	public static void main(String args[]) throws IOException {
		ProcessBuilder pb = new ProcessBuilder("CMD", "/C", "DIR");

		//redirigimos la salida a la del proceso padre-actual- 
		pb.redirectOutput(ProcessBuilder.Redirect.INHERIT);	    
		Process p = pb.start();		
	
	}
}// Ejemplo9
