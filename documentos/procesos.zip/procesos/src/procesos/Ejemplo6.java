package procesos;


import java.io.*;
import java.util.*;

public class Ejemplo6 {
	public static void main(String args[]) {
		
		File directorio = new File("C:/Users/Peter/eclipse-workspace/procesos/bin/");
		
		ProcessBuilder pb = new ProcessBuilder();
		Map entorno = pb.environment();
		System.out.println("Variables de entorno:");
		System.out.println(entorno);

		pb = new ProcessBuilder("java", "procesos.LeerNombre", "TORCUATO");		
		
		//pb = new ProcessBuilder("java", "procesos.Unsaludo", "SALUDOS");
		
		// devuelve el nombre del proceso y sus argumentos
		List l = pb.command();
		Iterator iter = l.iterator();
		System.out.println("\nArgumentos del comando:");
		while (iter.hasNext())
			System.out.println(iter.next());

		//obtener la salida devuelta por el proceso
		
		pb.directory(directorio);
		try {
			Process p = pb.start();
			InputStream is = p.getInputStream();
			int c;
			
			while ((c = is.read()) != -1)
				System.out.print((char) c);
			is.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}// Ejemplo6
