package org.poveda.primerMaven;

public class App {
	
	/**
	 *      ejemplos básicos.
	 *      
	 *      ejemplos mas complejos: https://commons.apache.org/proper/commons-net/
	 *      
	 * 	  
	 */
		 

  public static void main(String[] args) {
   
	  System.out.println("Conectando a redes remotas");
    
       // BasicoFTP.start();
	  
	   // ClienteSMTPConexion.start(); 
	  
	   // JavaMailSend.start();
	  
	   // JavaMailReceive_POP3.start();
	    
	   
    
    


	  
    
  
  }

}
